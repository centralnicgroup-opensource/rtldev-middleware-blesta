<?php

class TldPricing
{
    public static function getTLDPrices($tldClassMap, $zoneInformations)
    {
    }
}
