<?php
// Errors
$lang['Cornerstone.!error.security_key.empty'] = 'Please enter your Security Key.';

$lang['Cornerstone.name'] = 'Cornerstone';
$lang['Cornerstone.description'] = 'Cornerstone is one of the leading Christian owned and operated independent sales organizations in the merchant processing industry in the USA';

// Settings
$lang['Cornerstone.security_key'] = 'Security Key';
