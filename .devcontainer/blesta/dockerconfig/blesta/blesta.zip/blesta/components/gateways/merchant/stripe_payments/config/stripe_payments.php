<?php
Configure::set('StripePayments.migration_batch_size', 15);
