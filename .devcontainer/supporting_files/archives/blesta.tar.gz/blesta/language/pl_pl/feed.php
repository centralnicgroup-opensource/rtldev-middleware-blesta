<?php
/**
 * Feed
 *
 * @package blesta
 * @subpackage blesta.language.pl_pl
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['Feed.!error.disabled'] = 'Ten kanał danych jest wyłączony, aby go włączyć, odwiedź Ustawienia > Firma > Kanały w obszarze personelu.';
$lang['Feed.!error.invalid'] = 'Żądany zasób nie istnieje lub jest nieprawidłowy.';

