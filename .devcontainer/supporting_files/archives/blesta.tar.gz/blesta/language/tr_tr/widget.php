<?php
/**
 * Widget
 *
 * @package blesta
 * @subpackage blesta.language.tr_tr
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['Widget.submit'] = 'Gönder';
$lang['Widget.toggle_filters'] = 'Filtreleri Değiştir';

