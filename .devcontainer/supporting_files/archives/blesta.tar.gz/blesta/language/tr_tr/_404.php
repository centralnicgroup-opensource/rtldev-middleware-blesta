<?php
/**
 * 404
 *
 * @package blesta
 * @subpackage blesta.language.tr_tr
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['404.heading_error'] = '404';
$lang['404.text_error'] = 'Üzgünüz, erişmeye çalıştığınız sayfa mevcut değil veya taşınmış olabilir.';
$lang['404.text_go_to_home'] = 'Ana Sayfaya Git';

