<?php
/**
 * Admin System Upgrade
 *
 * @package blesta
 * @subpackage blesta.language.tr_tr
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['AdminSystemUpgrade.index.boxtitle_upgrade'] = 'Yükseltme Seçenekleri';
$lang['AdminSystemUpgrade.index.field_upgradesubmit'] = 'Ayarları Güncelle';
$lang['AdminSystemUpgrade.index.no_results'] = 'Yükseltme seçenekleri şu anda mevcut değildir.';
$lang['AdminSystemUpgrade.index.page_title'] = 'Ayarlar > Sistem > Yükseltme Seçenekleri';

