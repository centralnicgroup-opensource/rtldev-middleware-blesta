<?php
$lang['WidgetClient.submit'] = 'Submit';
