<?php
$lang['Widget.submit'] = 'Submit';
$lang['Widget.toggle_filters'] = 'Toggle Filters';
