<?php
$lang['AdminClientsService.totals.subtotal'] = 'Subtotal:';
