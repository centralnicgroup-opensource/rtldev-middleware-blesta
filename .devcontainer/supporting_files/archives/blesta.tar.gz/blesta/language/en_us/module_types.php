<?php
$lang['ModuleTypes.!error.name.valid'] = 'Name is invalid.';
$lang['ModuleTypes.!error.type_id.valid'] = 'The Module Type ID is invalid.';
