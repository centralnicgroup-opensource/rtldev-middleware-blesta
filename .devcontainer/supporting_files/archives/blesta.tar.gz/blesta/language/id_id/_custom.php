<?php
/**
 * Custom
 *
 * @package blesta
 * @subpackage blesta.language.id_id
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['_PaymentTypes.cash'] = 'Tunai';
$lang['_PaymentTypes.check'] = 'Periksa';
$lang['_PaymentTypes.in_house_credit'] = 'Kredit In House';
$lang['_PaymentTypes.money_order'] = 'Wesel';

