<?php
/**
 * Client Maintenance
 *
 * @package blesta
 * @subpackage blesta.language.id_id
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['ClientMaintenance.index.maintenance_heading'] = 'Mode Pemeliharaan';
$lang['ClientMaintenance.index.page_title'] = 'Pemeliharaan';

