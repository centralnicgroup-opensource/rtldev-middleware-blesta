<?php
/**
 * Module Types
 *
 * @package blesta
 * @subpackage blesta.language.id_id
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['ModuleTypes.!error.name.valid'] = 'Nama tidak valid.';
$lang['ModuleTypes.!error.type_id.valid'] = 'ID Jenis Modul tidak valid.';

