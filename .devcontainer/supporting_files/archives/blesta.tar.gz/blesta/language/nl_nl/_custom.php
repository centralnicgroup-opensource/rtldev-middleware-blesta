<?php
/**
 * Custom
 *
 * @package blesta
 * @subpackage blesta.language.nl_nl
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['_PaymentTypes.in_house_credit'] = 'In huis krediet';
$lang['_PaymentTypes.money_order'] = 'Postwissel';
$lang['_PaymentTypes.check'] = 'Controleer';
$lang['_PaymentTypes.cash'] = 'Contant';

