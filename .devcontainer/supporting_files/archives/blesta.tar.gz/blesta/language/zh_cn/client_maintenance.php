<?php
/**
 * Client Maintenance
 *
 * @package blesta
 * @subpackage blesta.language.zh_cn
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['ClientMaintenance.index.page_title'] = '维护';
$lang['ClientMaintenance.index.maintenance_heading'] = '维护模式';

