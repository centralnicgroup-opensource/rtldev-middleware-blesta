<?php
/**
 * Module Types
 *
 * @package blesta
 * @subpackage blesta.language.zh_cn
 * @copyright Copyright (c) 2024, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */

$lang['ModuleTypes.!error.type_id.valid'] = '模块类型 ID 无效。';
$lang['ModuleTypes.!error.name.valid'] = '名称无效。';

