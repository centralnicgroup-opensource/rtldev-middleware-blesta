<?php
// Controller get functions

$lang['ExtensionGeneratorController.getnodes.general_settings'] = 'General Settings';
$lang['ExtensionGeneratorController.getnodes.basic_info'] = 'Basic Info';
$lang['ExtensionGeneratorController.getnodes.plugin_database'] = 'Database Info';
$lang['ExtensionGeneratorController.getnodes.plugin_integrations'] = 'Core Integrations';
$lang['ExtensionGeneratorController.getnodes.module_fields'] = 'Module Fields';
$lang['ExtensionGeneratorController.getnodes.merchant_fields'] = 'Configuration Fields';
$lang['ExtensionGeneratorController.getnodes.merchant_features'] = 'Supported Features';
$lang['ExtensionGeneratorController.getnodes.nonmerchant_fields'] = 'Configuration Fields';
$lang['ExtensionGeneratorController.getnodes.additional_features'] = 'Additional Features';
$lang['ExtensionGeneratorController.getnodes.confirm'] = 'Confirmation';

$lang['ExtensionGeneratorController.getfieldtypes.text'] = 'Text';
$lang['ExtensionGeneratorController.getfieldtypes.textarea'] = 'Textarea';
$lang['ExtensionGeneratorController.getfieldtypes.checkbox'] = 'Checkbox';

$lang['ExtensionGeneratorController.gettablevels.staff'] = 'Staff';
$lang['ExtensionGeneratorController.gettablevels.client'] = 'Client';

$lang['ExtensionGeneratorController.gettasktypes.time'] = 'Time';
$lang['ExtensionGeneratorController.gettasktypes.interval'] = 'Interval';
