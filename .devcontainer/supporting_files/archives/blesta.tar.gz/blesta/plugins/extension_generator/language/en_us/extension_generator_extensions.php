<?php
$lang['ExtensionGeneratorExtensions.!error.name.empty'] = 'Please enter an extension name.';
$lang['ExtensionGeneratorExtensions.!error.company_id.exists'] = 'Invalid company ID.';
$lang['ExtensionGeneratorExtensions.!error.date_updated.format'] = 'Invalid date updated format.';
$lang['ExtensionGeneratorExtensions.!error.type.valid'] = 'Invalid extension type.';
$lang['ExtensionGeneratorExtensions.!error.form_type.valid'] = 'Invalid form type.';
$lang['ExtensionGeneratorExtensions.!error.code_examples.format'] = 'Invalid code examples option format.';
$lang['ExtensionGeneratorExtensions.!error.id.exists'] = 'The given extension ID is invalid.';


$lang['ExtensionGeneratorExtensions.gettypes.module'] = 'Module';
$lang['ExtensionGeneratorExtensions.gettypes.plugin'] = 'Plugin';
$lang['ExtensionGeneratorExtensions.gettypes.merchant'] = 'Merchant Gateway';
$lang['ExtensionGeneratorExtensions.gettypes.nonmerchant'] = 'Non-Merchant Gateway';


$lang['ExtensionGeneratorExtensions.getformtypes.basic'] = 'Basic';
$lang['ExtensionGeneratorExtensions.getformtypes.advanced'] = 'Advanced';
