<?php
$lang['ExtensionGeneratorPlugin.name'] = 'Extension Generator';
$lang['ExtensionGeneratorPlugin.description'] = 'This is a plugin for automatically generating files for new Blesta extensions';

$lang['ExtensionGeneratorPlugin.nav_secondary_staff.admin_main'] = 'Extension Generator';
