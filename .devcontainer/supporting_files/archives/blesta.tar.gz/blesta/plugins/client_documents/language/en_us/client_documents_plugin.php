<?php
$lang['ClientDocumentsPlugin.name'] = "Client Documents";
$lang['ClientDocumentsPlugin.description'] = "Upload files for download by specific clients.";

// Client navigation
$lang['ClientDocumentsPlugin.nav_primary_client.main'] = "Documents";

// Admin client action
$lang['ClientDocumentsPlugin.action_staff_client.index'] = "Documents";
