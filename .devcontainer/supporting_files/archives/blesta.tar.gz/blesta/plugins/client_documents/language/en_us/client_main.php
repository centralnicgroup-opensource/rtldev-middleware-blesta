<?php
$lang['ClientMain.index.page_title'] = "Documents";

// Index
$lang['ClientMain.index.boxtitle_documents'] = "Documents";
$lang['ClientMain.index.no_results'] = "There are no documents available for download.";
$lang['ClientMain.index.heading_name'] = "Name";
$lang['ClientMain.index.heading_description'] = "Description";
$lang['ClientMain.index.heading_date_added'] = "Date Added";
$lang['ClientMain.index.heading_options'] = "Options";
$lang['ClientMain.index.option_download'] = "Download";
