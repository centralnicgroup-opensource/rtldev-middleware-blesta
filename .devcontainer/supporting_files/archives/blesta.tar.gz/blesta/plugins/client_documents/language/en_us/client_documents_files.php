<?php
// Error messages
$lang['ClientDocumentsFiles.!error.client_id.exists'] = "The client does not exist.";
$lang['ClientDocumentsFiles.!error.name.valid'] = "A document name is required.";
$lang['ClientDocumentsFiles.!error.date_added.valid'] = "A valid date added is required.";
