<?php
/**
 * Client Documents parent model
 *
 * @package blesta
 * @subpackage blesta.plugins.client_documents
 * @copyright Copyright (c) 2014, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */
class ClientDocumentsModel extends AppModel
{
    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
    }
}
