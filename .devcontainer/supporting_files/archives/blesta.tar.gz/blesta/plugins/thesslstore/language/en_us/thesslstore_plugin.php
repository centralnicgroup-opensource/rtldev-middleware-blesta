<?php
$lang['TheSSLStorePlugin.name'] = "TheSSLStore Plugin";
$lang['TheSSLStorePlugin.getCronTasks.tss_expiration_reminder_name'] = "SSL Certificate Expiration Reminder";
$lang['TheSSLStorePlugin.getCronTasks.tss_expiration_reminder_desc'] = "A reminder will be sent 30-days before the certificate expiration date.";
