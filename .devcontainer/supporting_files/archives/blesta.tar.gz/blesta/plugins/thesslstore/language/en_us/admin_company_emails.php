<?php
$lang['AdminCompanyEmails.templates.Thesslstore.expiration_reminder_name'] = "SSL Certificate Expiration Reminder";
$lang['AdminCompanyEmails.templates.Thesslstore.expiration_reminder_desc'] = "Notice sent before 30 days of certificate expiration Date.";
?>