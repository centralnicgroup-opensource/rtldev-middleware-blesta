# TheSSLStore plugin

A Blesta plugin that integrates with [TheSSLStore](https://thesslstore.com/).

Originally created by TheSSLStore.

## Requirements

[TheSSLStore module](https://github.com/blesta/module-thesslstore)
