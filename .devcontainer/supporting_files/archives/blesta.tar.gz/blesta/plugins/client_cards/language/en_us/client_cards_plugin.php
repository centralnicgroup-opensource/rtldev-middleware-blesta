<?php
// Plugin name
$lang['ClientCardsPlugin.name'] = 'Client Cards';
$lang['ClientCardsPlugin.description'] = 'Displays client summary information in cards on the client interface.';

// Plugin cards
$lang['ClientCardsPlugin.card_client.services'] = 'Services';
$lang['ClientCardsPlugin.card_client.invoices'] = 'Invoices';
