<?php
$lang['Main.index.heading'] = 'Package Selection';
$lang['Main.index.subheading'] = 'Please select a package group below to continue.';
$lang['Main.index.group_heading'] = 'Select a package below.';
$lang['Main.index.field_pricing_id'] = 'Choose your billing cycle.';
$lang['Main.index.button_order'] = 'Order Now';
$lang['Main.index.client_limit'] = 'Limit Reached';
$lang['Main.index.sold_out'] = 'Out of Stock';

$lang['Main.index.field_currency'] = 'Currency:';

$lang['Main.packages.subheading'] = 'Select a package and then configure it down below.';
$lang['Main.packages.select_note'] = 'Drag to select a different package.';
$lang['Main.packages.price_start'] = 'Starting at';

$lang['Main.packages.box_select'] = 'Select';
$lang['Main.packages.box_selected'] = 'Selected';
$lang['Main.packages.box_client_limit'] = 'Limit Reached';
$lang['Main.packages.box_sold_out'] = 'Out of Stock';
