<?php
$lang['Summary.index.have_coupon'] = 'Use a coupon code';
$lang['Summary.index.coupon'] = 'Coupon';
$lang['Summary.index.coupon_btn'] = 'Redeem';
$lang['Summary.index.heading_summary'] = 'Order Summary';
$lang['Summary.index.summary_note'] = 'Any applicable taxes will be calculated after you register or log in.';
$lang['Summary.index.table_description'] = 'Description';
$lang['Summary.index.table_price'] = 'Price';
$lang['Summary.index.empty_cart'] = 'Empty Cart';
$lang['Summary.index.heading_paymethods'] = 'Payment Method';
$lang['Summary.index.paymethods_note'] = 'Please select your desired payment method.';
