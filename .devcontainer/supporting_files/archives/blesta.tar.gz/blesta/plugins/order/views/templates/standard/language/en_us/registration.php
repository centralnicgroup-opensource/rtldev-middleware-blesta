<?php
$lang['Registration.signup.header_signup'] = 'Sign up';
