<?php
$lang['Cart.index.header_cart'] = 'Review Order';
$lang['Cart.index.table_description'] = 'Description';
$lang['Cart.index.table_term'] = 'Term';
$lang['Cart.index.table_qty'] = 'Quantity';
$lang['Cart.index.table_price'] = 'Price';
$lang['Cart.index.checkout_btn'] = 'Checkout';
$lang['Cart.index.order_more_btn'] = 'Order More Items';
$lang['Cart.index.edit_item'] = 'Edit';
$lang['Cart.index.remove_item'] = 'Remove';
$lang['Cart.index.empty_cart'] = 'Your cart is empty. Start by <a href="%1$s">choosing a plan »</a>'; // %1$s is the URI to the order home page
