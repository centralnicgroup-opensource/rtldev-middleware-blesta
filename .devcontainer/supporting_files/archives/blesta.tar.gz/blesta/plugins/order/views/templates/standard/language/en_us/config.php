<?php
$lang['Config.index.header_configuration'] = 'Configuration';
$lang['Config.index.header_configure_service'] = 'Configure %1$s'; // %1$s is the service name to configure
$lang['Config.index.header_term'] = 'Term and Price';
$lang['Config.index.header_module'] = 'Configurable Options'; // %1$s is the name of the module
$lang['Config.index.header_addons'] = 'Available Add-Ons';
$lang['Config.index.continue_btn'] = 'Continue';
