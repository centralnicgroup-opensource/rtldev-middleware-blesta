<?php
$lang['Summary.index.box_heading'] = 'Your Cart';
$lang['Summary.index.login_customer'] = 'Existing Customer?';
$lang['Summary.index.login_link'] = 'Login';
$lang['Summary.index.link_resetpassword'] = 'Reset My Password';
$lang['Summary.index.field_username'] = 'Username';
$lang['Summary.index.field_password'] = 'Password';
$lang['Summary.index.login_btn'] = 'Login';
$lang['Summary.index.checkout_btn'] = 'Checkout';
$lang['Summary.index.have_coupon'] = 'Have a coupon?';
$lang['Summary.index.coupon'] = 'Coupon';
$lang['Summary.index.coupon_btn'] = 'Redeem';
$lang['Summary.index.cart_empty'] = 'There are no items in your cart.';
