<?php
$lang['Signup.index.header_login_or_signup'] = 'Register or Log In';
$lang['Signup.index.link_resetpassword'] = 'Reset My Password';
$lang['Signup.index.header_login'] = 'Log In';

$lang['Signup.index.heading_contact'] = 'Contact Information';
$lang['Signup.index.heading_billing'] = 'Billing Information';
$lang['Signup.index.heading_authentication'] = 'Authentication';
$lang['Signup.index.heading_settings'] = 'Additional Settings';
