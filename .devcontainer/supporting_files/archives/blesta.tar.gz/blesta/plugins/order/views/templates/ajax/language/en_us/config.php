<?php
$lang['Config.index.header_configuration'] = 'Configuration';
$lang['Config.index.header_configure_service'] = 'Configure %1$s'; // %1$s is the service name to configure
$lang['Config.index.config_notes'] = 'Select desired options, and continue to checkout.';
$lang['Config.index.header_term'] = 'Term and Price';
$lang['Config.index.header_module'] = 'Configurable Options';
$lang['Config.index.header_addons'] = 'Available Addons';
$lang['Config.index.addons_notes'] = 'Any selected addons will be configured on the next step.';
$lang['Config.index.continue_btn'] = 'Continue';
