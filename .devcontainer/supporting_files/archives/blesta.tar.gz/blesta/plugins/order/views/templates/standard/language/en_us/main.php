<?php
$lang['Main.steps.step_1_name'] = 'Step 1';
$lang['Main.steps.step_1_description'] = 'Choose your plan';
$lang['Main.steps.step_2_name'] = 'Step 2';
$lang['Main.steps.step_2_description'] = 'Configuration';
$lang['Main.steps.step_3_name'] = 'Step 3';
$lang['Main.steps.step_3_description'] = 'Review Order';
$lang['Main.steps.step_4_name'] = 'Step 4';
$lang['Main.steps.step_4_description'] = 'Checkout';

$lang['Main.index.field_currency'] = 'Currency:';

$lang['Main.index.select_btn'] = 'Add to Cart';
$lang['Main.index.sold_out'] = 'Out of Stock';
$lang['Main.index.client_limit'] = 'Limit Reached';
