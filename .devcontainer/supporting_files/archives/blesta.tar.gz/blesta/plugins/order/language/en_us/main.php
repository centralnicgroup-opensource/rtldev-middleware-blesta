<?php
$lang['Main.!error.package_limits'] = "Package limits have been reached for all packages in the selected group.";
$lang['Main.index.package_price'] = "%1\$s @ %2\$s"; // %1$s is the term, %2$s is the price
$lang['Main.index.package_price_recurring'] = "%1\$s @ %2\$s (renews @ %3\$s)"; // %1$s is the term, %2$s is the initial price, %3$s is the renewal price
