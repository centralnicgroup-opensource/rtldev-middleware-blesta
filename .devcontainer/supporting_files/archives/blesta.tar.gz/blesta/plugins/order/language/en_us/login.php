<?php
$lang['Login.!error.captcha.invalid'] = 'The captcha entered was invalid. Please try again.';
