<?php
// Success
$lang['AdminExcludedPackages.!success.packages_updated'] = "The excluded packages were successfully updated.";

// Index
$lang['AdminExcludedPackages.index.boxtitle_excluded_packages'] = "Excluded Packages";
$lang['AdminExcludedPackages.index.heading_available_packages'] = "Available Packages";
$lang['AdminExcludedPackages.index.field_updatesubmit'] = "Update Settings";
$lang['AdminExcludedPackages.index.text_no_packages'] = 'There are no active packages available.';