<?php
$lang['OrderOrders.getstatuses.pending'] = "In Review";
$lang['OrderOrders.getstatuses.accepted'] = "Accepted";
$lang['OrderOrders.getstatuses.fraud'] = "Fraud";
$lang['OrderOrders.getstatuses.canceled'] = "Canceled";
