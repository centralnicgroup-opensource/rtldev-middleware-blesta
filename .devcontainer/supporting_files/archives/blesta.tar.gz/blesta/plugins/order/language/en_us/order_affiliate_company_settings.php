<?php
$lang['OrderAffiliateCompanySettings.!error.company_id.exists'] = 'Invalid company ID.';

// Get commission types
$lang['OrderAffiliateCompanySettings.getcommissiontypes.fixed'] = 'Fixed';
$lang['OrderAffiliateCompanySettings.getcommissiontypes.percentage'] = 'Percentage';

// Get order frequencies
$lang['OrderAffiliateCompanySettings.getorderfrequencies.first'] = 'First';
$lang['OrderAffiliateCompanySettings.getorderfrequencies.any'] = 'Any';
