<?php
$lang['Summary.index.price'] = "@ %1\$s"; // %1$s is the price per term
$lang['Summary.index.totals.discount'] = "Discount:";
$lang['Summary.index.totals.subtotal'] = "Subtotal:";
$lang['Summary.index.totals.tax'] = "%1\$s:"; // %1$s is the tax name
$lang['Summary.index.totals.total'] = "Total Due Today:";
$lang['Summary.index.totals.total_recurring'] = "Total When Renewing:";
$lang['Summary.index.totals.total_recurring_amount'] = "%1\$s %2\$s @ %3\$s"; // %1$s is the term, %2$s is the period, %3$s is the amount
