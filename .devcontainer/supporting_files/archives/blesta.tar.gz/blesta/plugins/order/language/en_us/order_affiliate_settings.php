<?php
$lang['OrderAffiliateSettings.!error.affiliate_id.exists'] = 'Invalid affiliate ID.';
