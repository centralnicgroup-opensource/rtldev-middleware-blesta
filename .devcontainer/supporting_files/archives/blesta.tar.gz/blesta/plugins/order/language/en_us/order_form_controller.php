<?php
$lang['OrderFormController.!notice.items_removed'] = "Some items have been removed from your cart because of package restrictions";