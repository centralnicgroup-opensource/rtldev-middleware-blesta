<?php
$lang['AdminCompanyMessengers.templates.Order.received_staff_name'] = "Order Received";
$lang['AdminCompanyMessengers.templates.Order.received_staff_desc'] = "Notice sent when an order is received.";
