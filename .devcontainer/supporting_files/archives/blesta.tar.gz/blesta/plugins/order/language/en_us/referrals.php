<?php
// Referrals Page
$lang['Referrals.index.boxtitle_referrals'] = 'Referrals';
$lang['Referrals.index.category_pending'] = 'Pending';
$lang['Referrals.index.category_mature'] = 'Mature';
$lang['Referrals.index.category_canceled'] = 'Canceled';
$lang['Referrals.index.no_results'] = 'There are currently no referrals with this status.';

$lang['Referrals.index.heading_order'] = 'Order #';
$lang['Referrals.index.heading_name'] = 'Name';
$lang['Referrals.index.heading_amount'] = 'Amount';
$lang['Referrals.index.heading_currency'] = 'Currency';
$lang['Referrals.index.heading_commission'] = 'Commission';
$lang['Referrals.index.heading_date_added'] = 'Date Added';
