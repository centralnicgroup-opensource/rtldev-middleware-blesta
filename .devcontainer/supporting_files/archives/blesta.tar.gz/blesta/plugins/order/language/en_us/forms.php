<?php
$lang['Forms.index.order_now'] = 'Order Now';
$lang['Forms.index.register'] = 'Register';
