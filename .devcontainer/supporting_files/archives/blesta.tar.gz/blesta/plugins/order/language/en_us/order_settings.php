<?php
$lang['OrderSettings.!error.embed_code.parse'] = 'Embed code parse error: %1$s'; // %1$s is the parse error

$lang['OrderSettings.getantifraud.fraudlabspro'] = 'FraudLabs Pro';
$lang['OrderSettings.getantifraud.maxmind'] = 'MaxMind Legacy';
$lang['OrderSettings.getantifraud.maxmind_v2'] = 'MaxMind v2';
