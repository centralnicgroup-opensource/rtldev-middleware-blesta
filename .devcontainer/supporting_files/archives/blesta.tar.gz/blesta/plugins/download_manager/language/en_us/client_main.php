<?php

// Text
$lang['ClientMain.!text.root_directory'] = "Home";


// Index
$lang['ClientMain.index.page_title'] = "Downloads";
$lang['ClientMain.index.boxtitle_downloads'] = "Downloads";

$lang['ClientMain.index.login'] = "You must log in to view downloads in this section.";
$lang['ClientMain.index.no_downloads'] = "There are no downloads available in this section.";
