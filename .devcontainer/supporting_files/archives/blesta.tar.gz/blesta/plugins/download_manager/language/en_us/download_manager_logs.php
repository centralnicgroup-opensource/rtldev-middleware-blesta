<?php
/**
 * Download Manager Logs model language
 */

// Errors
$lang['DownloadManagerLogs.!error.file_id.exists'] = "The file does not exist.";
$lang['DownloadManagerLogs.!error.client_id.exists'] = "The client does not exist.";
$lang['DownloadManagerLogs.!error.contact_id.exists'] = "The contact does not exist.";
