<?php
$lang['DownloadManagerPlugin.name'] = "Download Manager";
$lang['DownloadManagerPlugin.description'] = "Allows files to be uploaded and made available for clients to download.";
$lang['DownloadManagerPlugin.client_main'] = "Downloads";
$lang['DownloadManagerPlugin.admin_main'] = 'Download Manager';
