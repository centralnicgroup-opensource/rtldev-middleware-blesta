<?php
// Errors
$lang['FeedReaderFeeds.!error.url.valid'] = "The URL given is invalid.";
$lang['FeedReaderFeeds.!error.company_id.exists'] = "The company specified does not exist.";
$lang['FeedReaderFeeds.!error.updated.valid'] = "You must specify a valid update date.";
$lang['FeedReaderFeeds.!error.feed_id.exists'] = "The feed given does not exist.";
$lang['FeedReaderFeeds.!error.staff_id.exists'] = "The staff member specified does not exist.";
$lang['FeedReaderFeeds.!error.date.valid'] = "The data specified is invalid.";
