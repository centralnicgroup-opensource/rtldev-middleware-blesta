<?php
// Errors
$lang['FeedReaderPlugin.!error.libxml_required'] = "The libxml extension is required for this plugin.";
$lang['FeedReaderPlugin.!error.dom_required'] = "The dom extension is required for this plugin.";


$lang['FeedReaderPlugin.name'] = "Feed Reader";
$lang['FeedReaderPlugin.description'] = "View any RSS/Atom feed right on your dashboard.";
