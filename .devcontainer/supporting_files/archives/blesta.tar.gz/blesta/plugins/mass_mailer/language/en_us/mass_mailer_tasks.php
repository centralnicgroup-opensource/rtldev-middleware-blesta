<?php
// Errors
$lang['MassMailerTasks.!error.job_id.valid'] = 'Invalid job ID.';
