<?php
// Errors
$lang['MassMailerExports.!error.task_id.valid'] = 'Invalid task ID.';
