<?php
// Success
$lang['MassMailerController.!success.mail_job_added'] = 'The mailing job has been successfully queued. Emails will be sent via cron.';
$lang['MassMailerController.!success.export_job_added'] = 'The export has been successfully queued. It will be made available on the listing page once it has been processed via cron.';
