<?php
$lang['Config.export.id_code'] = "Client ID";
$lang['Config.export.first_name'] = "First Name";
$lang['Config.export.last_name'] = "Last Name";
$lang['Config.export.company'] = "Company";
$lang['Config.export.email'] = "Email";
$lang['Config.export.date_added'] = "Date Added";
$lang['Config.export.package_name'] = "Package";
$lang['Config.export.service_name'] = "Service";
$lang['Config.export.service_date_renews'] = "Renew Date";
$lang['Config.export.module_name'] = "Module";
$lang['Config.export.module_label'] = "Module Row";
