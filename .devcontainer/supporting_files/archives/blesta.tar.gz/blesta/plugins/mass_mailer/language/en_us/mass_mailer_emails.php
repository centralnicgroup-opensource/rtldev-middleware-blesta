<?php
// Errors
$lang['MassMailerEmails.!error.job_id.valid'] = 'Invalid job ID.';
$lang['MassMailerEmails.!error.job_id.unique'] = 'The job is already assigned an email.';
$lang['MassMailerEmails.!error.from_name.empty'] = 'Please enter a from name.';
$lang['MassMailerEmails.!error.from_address.valid'] = 'Please enter a valid from email address.';
$lang['MassMailerEmails.!error.subject.empty'] = 'Please enter a subject.';
$lang['MassMailerEmails.!error.html.empty'] = 'Please enter HTML email content.';
$lang['MassMailerEmails.!error.log.valid'] = 'The log option must be set to 0 or 1.';
