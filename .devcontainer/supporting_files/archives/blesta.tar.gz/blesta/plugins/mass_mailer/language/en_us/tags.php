<?php
$lang['Tags.client.id_code'] = 'ID';
$lang['Tags.client.status'] = 'Status';
$lang['Tags.contact.first_name'] = 'First Name';
$lang['Tags.contact.last_name'] = 'Last Name';
$lang['Tags.contact.company'] = 'Company Name';
$lang['Tags.contact.address1'] = 'Address 1';
$lang['Tags.contact.address2'] = 'Address 2';
$lang['Tags.contact.city'] = 'City';
$lang['Tags.contact.state'] = 'State';
$lang['Tags.contact.country'] = 'Country';
$lang['Tags.contact.zip'] = 'Postal Code';
$lang['Tags.contact.email'] = 'Email';
$lang['Tags.contact.date_added'] = 'Member Date';

$lang['Tags.package.name'] = 'Package Name';
$lang['Tags.package.description'] = 'Package Text Description';
$lang['Tags.package.description_html'] = 'Package HTML Description';
$lang['Tags.package.status'] = 'Package Status';
$lang['Tags.service.name'] = 'Label';
$lang['Tags.service.date_added'] = 'Date Added';
$lang['Tags.service.date_renews'] = 'Date Renews';
$lang['Tags.service.date_last_renewed'] = 'Date Last Renewed';
$lang['Tags.service.date_suspended'] = 'Date Suspended';
$lang['Tags.service.date_canceled'] = 'Date Canceled';
$lang['Tags.service.status'] = 'Status';
$lang['Tags.module.name'] = 'Module Name';
$lang['Tags.module.label'] = 'Module Row Label';
