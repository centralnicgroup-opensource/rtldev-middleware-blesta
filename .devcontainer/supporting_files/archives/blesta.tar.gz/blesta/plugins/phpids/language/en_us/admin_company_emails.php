<?php
$lang['AdminCompanyEmails.templates.Phpids.email_alert_name'] = "PHPIDS Intrusion Alert";
$lang['AdminCompanyEmails.templates.Phpids.email_alert_desc'] = "PHPIDS intrusion dection alert email, sent to addresses configured under the PHPIDS plugin.";
