<?php
// Plugin details
$lang['PhpidsPlugin.name'] = "PHPIDS";
$lang['PhpidsPlugin.description'] = "Intrusion Detection System to help identify suspicious activity.";
