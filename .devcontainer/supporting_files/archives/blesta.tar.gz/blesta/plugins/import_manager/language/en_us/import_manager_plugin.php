<?php
$lang['ImportManagerPlugin.name'] = "Import Manager";
$lang['ImportManagerPlugin.description'] = "Imports your data from another system into Blesta.";
