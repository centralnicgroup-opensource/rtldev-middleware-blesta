<?php
/**
 * Generic Blesta Migrator
 *
 * @package blesta
 * @subpackage blesta.plugins.import_manager.components.migrators.blesta
 * @copyright Copyright (c) 2010, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 */
class BlestaMigrator extends Migrator
{
    /**
     * Runs the import, sets any Input errors encountered
     */
    public function import()
    {
    }
}
