<?php
/*
 * en_us language for the Domain Manager Domains model
 */
$lang['DomainsDomains.!error.invoices_renew_service'] = 'The domain cannot be renewed until all invoices containing this domain have been paid.';
$lang['DomainsDomains.!error.invalid_term'] = 'This domain cannot be renewed for the selected amount of years.';
