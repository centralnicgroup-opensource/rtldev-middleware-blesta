<?php
$lang['AdminCompanyEmails.templates.Domains.domain_renewal_1_name'] = 'Domain Renewal Reminder 1';
$lang['AdminCompanyEmails.templates.Domains.domain_renewal_1_desc'] = 'First notice sent to a client when their domain will soon expire.';

$lang['AdminCompanyEmails.templates.Domains.domain_renewal_2_name'] = 'Domain Renewal Reminder 2';
$lang['AdminCompanyEmails.templates.Domains.domain_renewal_2_desc'] = 'Second notice sent to a client when their domain will soon expire.';

$lang['AdminCompanyEmails.templates.Domains.domain_expiration_name'] = 'Domain Expiration Notice';
$lang['AdminCompanyEmails.templates.Domains.domain_expiration_desc'] = 'Notice sent to a client soon after their domain has expired.';
