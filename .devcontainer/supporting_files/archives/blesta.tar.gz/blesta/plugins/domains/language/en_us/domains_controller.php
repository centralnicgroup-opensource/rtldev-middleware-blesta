<?php
/*
 * en_us language for the Domain Manager parent controller
 */
$lang['DomainsController.example'] = 'Example language';
