## [1.1.1](https://github.com/hexonet/blesta-ispapi-registrar/compare/v1.1.0...v1.1.1) (2018-12-14)


### Bug Fixes

* **pkg:** modified package.json to include zip files in the release ([ca55c51](https://github.com/hexonet/blesta-ispapi-registrar/commit/ca55c51))

# [1.1.0](https://github.com/hexonet/blesta-ispapi-registrar/compare/v1.0.0...v1.1.0) (2018-12-14)


### Features

* **pkg:** Added Makefile ([2ece17c](https://github.com/hexonet/blesta-ispapi-registrar/commit/2ece17c))

# 1.0.0 (2018-12-12)


### Bug Fixes

* **pkg:** added .gitignore file ([09d86a1](https://github.com/hexonet/blesta-ispapi-registrar/commit/09d86a1))
* **pkg:** added evaluation on registration and renewal periods acc. QueryDomainOptions ([c7722e5](https://github.com/hexonet/blesta-ispapi-registrar/commit/c7722e5))
* **pkg:** fixed a bug in admin settings tab ([cb336b1](https://github.com/hexonet/blesta-ispapi-registrar/commit/cb336b1))
