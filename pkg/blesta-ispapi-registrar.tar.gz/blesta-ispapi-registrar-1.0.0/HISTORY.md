# 1.0.0 (2018-12-12)


### Bug Fixes

* **pkg:** added .gitignore file ([09d86a1](https://github.com/hexonet/blesta-ispapi-registrar/commit/09d86a1))
* **pkg:** added evaluation on registration and renewal periods acc. QueryDomainOptions ([c7722e5](https://github.com/hexonet/blesta-ispapi-registrar/commit/c7722e5))
* **pkg:** fixed a bug in admin settings tab ([cb336b1](https://github.com/hexonet/blesta-ispapi-registrar/commit/cb336b1))
